package com.oneui9.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: LauncherViewModel) {
    val context = LocalContext.current
    val apps by viewModel.apps.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var isDrawerOpen by remember { mutableStateOf(false) }
    var isHomeUpOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var currentTime by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = Date()
            delay(15_000L)
        }
    }

    val glassAlpha = (0.14f + settings.glossIntensity * 0.34f).coerceIn(0.12f, 0.55f)
    val specularBorderBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = (0.35f + settings.glossIntensity * 0.55f).coerceAtMost(0.95f)),
            Color.White.copy(alpha = 0.08f)
        ),
        start = Offset(0f, 0f),
        end = Offset(220f, 220f)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {},
                onLongClick = { isHomeUpOpen = true }
            )
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount < -36f && !isDrawerOpen) {
                        isDrawerOpen = true
                    }
                }
            }
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. One UI 9 Dual Clock & Weather Glass Pill Widget
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xFF0F172A).copy(alpha = glassAlpha))
                    .border(1.2.dp, specularBorderBrush, RoundedCornerShape(30.dp))
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(currentTime),
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White
                    )
                    Text(
                        text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(currentTime),
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "Weather",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "72°F",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = "One UI 9 Glass",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                    }
                }
            }

            // 2. Home Screen App Grid
            val maxHomeIcons = settings.gridSize.columns * (settings.gridSize.rows - 1)
            val homeApps = remember(apps, searchQuery, maxHomeIcons) {
                val filtered = if (searchQuery.isBlank()) apps else apps.filter {
                    it.label.contains(searchQuery, ignoreCase = true)
                }
                filtered.take(maxHomeIcons)
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(settings.gridSize.columns),
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(homeApps, key = { it.packageName + "/" + it.activityName }) { app ->
                    OneUiSquircleAppItem(
                        app = app,
                        settings = settings,
                        specularBorderBrush = specularBorderBrush,
                        glassAlpha = glassAlpha,
                        onClick = { viewModel.launchApp(context, app) }
                    )
                }
            }

            // 3. Finder Search Pill + 5-Icon Bottom Dock
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Finder Search", color = Color.White.copy(alpha = 0.75f)) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                            }
                        } else {
                            IconButton(onClick = { isHomeUpOpen = true }) {
                                Icon(Icons.Default.Settings, contentDescription = "Home Up", tint = Color.White)
                            }
                        }
                    },
                    singleLine = true,
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .padding(bottom = 14.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F172A).copy(alpha = glassAlpha))
                        .border(1.dp, specularBorderBrush, CircleShape)
                )

                val dockApps = remember(apps) { apps.take(5) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (settings.dockGlassCapsule) {
                                Modifier
                                    .clip(RoundedCornerShape(32.dp))
                                    .background(Color(0xFF0F172A).copy(alpha = glassAlpha))
                                    .border(1.2.dp, specularBorderBrush, RoundedCornerShape(32.dp))
                            } else {
                                Modifier
                            }
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    dockApps.forEach { app ->
                        OneUiSquircleAppItem(
                            app = app,
                            settings = settings.copy(showAppLabels = false),
                            specularBorderBrush = specularBorderBrush,
                            glassAlpha = glassAlpha,
                            onClick = { viewModel.launchApp(context, app) }
                        )
                    }
                }
            }
        }

        // 4. Swipe-Up Full-Screen Frosted Glass App Drawer
        AnimatedVisibility(
            visible = isDrawerOpen,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            BackHandler { isDrawerOpen = false }
            var drawerQuery by remember { mutableStateOf("") }
            val drawerApps = remember(apps, drawerQuery) {
                if (drawerQuery.isBlank()) apps
                else apps.filter { it.label.contains(drawerQuery, ignoreCase = true) }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF090D1A).copy(alpha = (0.72f + settings.glossIntensity * 0.22f).coerceAtMost(0.95f)))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                OutlinedTextField(
                    value = drawerQuery,
                    onValueChange = { drawerQuery = it },
                    placeholder = { Text("Search in Apps", color = Color.White.copy(alpha = 0.75f)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White) },
                    trailingIcon = {
                        IconButton(onClick = { isDrawerOpen = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close Drawer", tint = Color.White)
                        }
                    },
                    singleLine = true,
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(settings.gridSize.columns),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(drawerApps, key = { it.packageName + "/" + it.activityName }) { app ->
                        OneUiSquircleAppItem(
                            app = app,
                            settings = settings,
                            specularBorderBrush = specularBorderBrush,
                            glassAlpha = glassAlpha,
                            onClick = { viewModel.launchApp(context, app) }
                        )
                    }
                }
            }
        }

        // 5. Long-Press Home Up Customization Bottom Sheet
        if (isHomeUpOpen) {
            ModalBottomSheet(
                onDismissRequest = { isHomeUpOpen = false },
                containerColor = Color(0xFF0F172A).copy(alpha = 0.94f),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("Home Up • One UI 9 Glass", fontSize = 20.sp, fontWeight = FontWeight.Bold)

                    Text("Home & Drawer Grid Size", fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridSizeOption.entries.forEach { option ->
                            FilterChip(
                                selected = settings.gridSize == option,
                                onClick = { viewModel.updateSettings { it.copy(gridSize = option) } },
                                label = { Text(option.label) }
                            )
                        }
                    }

                    Text("Gloss & Glass Intensity: ${(settings.glossIntensity * 100).toInt()}%", fontSize = 14.sp)
                    Slider(
                        value = settings.glossIntensity,
                        onValueChange = { v -> viewModel.updateSettings { it.copy(glossIntensity = v) } },
                        valueRange = 0.15f..1.0f
                    )

                    Text("Icon Size: ${(settings.iconScale * 100).toInt()}%", fontSize = 14.sp)
                    Slider(
                        value = settings.iconScale,
                        onValueChange = { v -> viewModel.updateSettings { it.copy(iconScale = v) } },
                        valueRange = 0.80f..1.20f
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show App Labels")
                        Switch(
                            checked = settings.showAppLabels,
                            onCheckedChange = { checked -> viewModel.updateSettings { it.copy(showAppLabels = checked) } }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Glossy Glass Capsule Dock")
                        Switch(
                            checked = settings.dockGlassCapsule,
                            onCheckedChange = { checked -> viewModel.updateSettings { it.copy(dockGlassCapsule = checked) } }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.openWallpaperPicker(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Change Wallpaper")
                        }
                        Button(
                            onClick = { viewModel.openDefaultHomeSettings(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Default Home")
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun OneUiSquircleAppItem(
    app: AppInfo,
    settings: HomeUpSettings,
    specularBorderBrush: Brush,
    glassAlpha: Float,
    onClick: () -> Unit
) {
    val squircleSize = (58.dp * settings.iconScale)
    val squircleShape = RoundedCornerShape(26.dp)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp, horizontal = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(squircleSize)
                .shadow(elevation = 8.dp, shape = squircleShape, clip = false)
                .clip(squircleShape)
                .background(Color.White.copy(alpha = glassAlpha * 0.55f))
                .border(1.2.dp, specularBorderBrush, squircleShape)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (app.iconBitmap != null) {
                Image(
                    bitmap = app.iconBitmap,
                    contentDescription = app.label,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(20.dp))
                )
            }
        }
        if (settings.showAppLabels) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}