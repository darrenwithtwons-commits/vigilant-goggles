package com.oneui9.launcher

import androidx.compose.ui.graphics.ImageBitmap

data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val iconBitmap: ImageBitmap?
)

enum class GridSizeOption(val columns: Int, val rows: Int, val label: String) {
    GRID_4X5(4, 5, "4x5"),
    GRID_4X6(4, 6, "4x6"),
    GRID_5X6(5, 6, "5x6");

    companion object {
        fun fromName(name: String?): GridSizeOption =
            entries.firstOrNull { it.name == name } ?: GRID_4X5
    }
}

data class HomeUpSettings(
    val gridSize: GridSizeOption = GridSizeOption.GRID_4X5,
    val glossIntensity: Float = 0.72f,
    val iconScale: Float = 1.0f,
    val showAppLabels: Boolean = true,
    val dockGlassCapsule: Boolean = true
)