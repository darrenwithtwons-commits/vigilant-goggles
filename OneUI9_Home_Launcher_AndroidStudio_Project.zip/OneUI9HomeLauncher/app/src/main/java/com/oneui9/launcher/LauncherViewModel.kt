package com.oneui9.launcher

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("one_ui_9_home_up", Context.MODE_PRIVATE)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<HomeUpSettings> = _settings.asStateFlow()

    init {
        loadInstalledApps()
    }

    private fun loadSettings(): HomeUpSettings {
        return HomeUpSettings(
            gridSize = GridSizeOption.fromName(prefs.getString("grid_size", "GRID_4X5")),
            glossIntensity = prefs.getFloat("gloss_intensity", 0.72f),
            iconScale = prefs.getFloat("icon_scale", 1.0f),
            showAppLabels = prefs.getBoolean("show_labels", true),
            dockGlassCapsule = prefs.getBoolean("dock_capsule", true)
        )
    }

    fun updateSettings(transform: (HomeUpSettings) -> HomeUpSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        prefs.edit()
            .putString("grid_size", updated.gridSize.name)
            .putFloat("gloss_intensity", updated.glossIntensity)
            .putFloat("icon_scale", updated.iconScale)
            .putBoolean("show_labels", updated.showAppLabels)
            .putBoolean("dock_capsule", updated.dockGlassCapsule)
            .apply()
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                val pm = getApplication<Application>().packageManager
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
                resolveInfos.mapNotNull { info ->
                    val pkg = info.activityInfo.packageName
                    val act = info.activityInfo.name
                    if (pkg == getApplication<Application>().packageName) return@mapNotNull null
                    val label = info.loadLabel(pm).toString()
                    val drawable = runCatching { pm.getApplicationIcon(pkg) }
                        .getOrElse { info.loadIcon(pm) }
                    val bitmap = runCatching {
                        drawable.toBitmap(width = 144, height = 144).asImageBitmap()
                    }.getOrNull()
                    AppInfo(
                        label = label,
                        packageName = pkg,
                        activityName = act,
                        iconBitmap = bitmap
                    )
                }.sortedBy { it.label.lowercase() }
            }
            _apps.value = loaded
        }
    }

    fun launchApp(context: Context, app: AppInfo) {
        runCatching {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = ComponentName(app.packageName, app.activityName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
            }
            context.startActivity(intent)
        }.onFailure {
            context.packageManager.getLaunchIntentForPackage(app.packageName)?.let { fallback ->
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fallback)
            }
        }
    }

    fun openWallpaperPicker(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_SET_WALLPAPER).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Change Wallpaper"))
        }
    }

    fun openDefaultHomeSettings(context: Context) {
        runCatching {
            val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}