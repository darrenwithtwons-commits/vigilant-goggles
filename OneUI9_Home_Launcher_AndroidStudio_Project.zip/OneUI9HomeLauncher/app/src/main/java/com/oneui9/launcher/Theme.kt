package com.oneui9.launcher

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val OneUiColorScheme = darkColorScheme(
    primary = Color(0xFF38BDF8),
    secondary = Color(0xFF0077FF),
    tertiary = Color(0xFF34D399),
    background = Color.Transparent,
    surface = Color(0xFF0F172A),
    onPrimary = Color(0xFF041322),
    onBackground = Color.White,
    onSurface = Color.White
)

private val OneUiShapes = Shapes(
    small = RoundedCornerShape(18.dp),
    medium = RoundedCornerShape(26.dp),
    large = RoundedCornerShape(32.dp)
)

@Composable
fun OneUi9LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = OneUiColorScheme,
        shapes = OneUiShapes,
        content = content
    )
}